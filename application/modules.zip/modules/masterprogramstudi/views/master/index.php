<?php

$num_columns	= 28;
$can_delete	= $this->auth->has_permission('MasterProgramStudi.Master.Delete');
$can_edit		= $this->auth->has_permission('MasterProgramStudi.Master.Edit');
$has_records	= isset($records) && is_array($records) && count($records);

?>
<div class="admin-box">
	 <form action="<?php $this->uri->uri_string() ?>" method="get" accept-charset="utf-8">
	 
    	<table>
        	<tr>
            	<td>
                	Nama
                </td>
                <td>Fakultas
                </td>
                 </tr>
            
            <tr>
                <td>
                	<input id='fillnama' type='text' name='fillnama' value="<?php echo set_value('fillnama', isset($fillnama) ? $fillnama : ''); ?>" />
				</td> 
                 
                <td>
                	<select name="fillfakultas" id="fillfakultas" class="chosen-select-deselect">
						<option value=""></option>
						<?php if (isset($masterfakultass) && is_array($masterfakultass) && count($masterfakultass)):?>
						<?php foreach($masterfakultass as $record):?>
							<option value="<?php echo $record->id?>" <?php if(isset($fillfakultas))  echo  ($record->id==$fillfakultas) ? "selected" : ""; ?>><?php echo $record->nama_fakultas; ?></option>
							<?php endforeach;?>
						<?php endif;?>
					</select>
                </td> 
			 
                <td valign="top">
                	 <input type="submit" name="Act" class="btn btn-primary" value="Cari "  />
               	</td> 
            </tr>
            
        </table>
    <?php echo form_close(); ?>
   <div class="alert alert-block alert-warning fade in ">
      <a class="close" data-dismiss="alert">&times;</a>
       Jumlah :  <?php echo isset($total) ? $total : ''; ?>
    </div>
	<?php echo form_open($this->uri->uri_string()); ?>
		<table class="table table-striped">
			<thead>
				<tr>
					<?php if ($can_delete && $has_records) : ?>
					<th class="column-check"><input class="check-all" type="checkbox" /></th>
					<?php endif;?>
					
					<th>Kode Fakultas</th>
					<th>Kode Program Studi</th>
					<th>Kode Jenjang Studi</th>
					<th>Nama Program Studi</th>
					<th>Semester Awal</th>
					<th>No SK DIKTI</th>
					<th>Tanggal SK DIKTI</th>
					<th>Tanggal Akhir SK DIKTI</th>
					<th>Jumlah SKS Lulus</th>
					<th>Kode Status</th>
					<th>Tahun Semester Mulai</th>
					<th>E-Mail Program Studi</th>
					<th>Tanggal Pendirian Progran Studi</th>
					<th>No SK Akreditasi</th>
					<th>Tanggal SK Akeditasi</th>
					<th>Tanggal Akhir SK Akreditasi</th>
					<th>Kode Status Akreditasi</th>
					<th>Frekuensi Pemuktahiran Kurikulum</th>
					<th>Pelaksanaan Frekuensi Pemuktahiran Kurikulum</th>
					<th>NIDN Ketua Program Studi</th>
					<th>Telepon Ketua Progra Studi</th>
					<th>Fax Program Studi</th>
					<th>Nama Operator</th>
					<th>Handphone Operator</th>
					<th>Photo Program Studi</th>
					<th>Telepon Program Studi</th>
				</tr>
			</thead>
			<?php if ($has_records) : ?>
			<tfoot>
				<?php if ($can_delete) : ?>
				<tr>
					<td colspan="<?php echo $num_columns; ?>">
						<?php echo lang('bf_with_selected'); ?>
						<input type="submit" name="delete" id="delete-me" class="btn btn-danger" value="<?php echo lang('bf_action_delete'); ?>" onclick="return confirm('<?php e(js_escape(lang('masterprogramstudi_delete_confirm'))); ?>')" />
					</td>
				</tr>
				<?php endif; ?>
			</tfoot>
			<?php endif; ?>
			<tbody>
				<?php
				if ($has_records) :
					foreach ($records as $record) :
				?>
				<tr>
					<?php if ($can_delete) : ?>
					<td class="column-check"><input type="checkbox" name="checked[]" value="<?php echo $record->id; ?>" /></td>
					<?php endif;?>
					
				<?php if ($can_edit) : ?>
					<td><?php echo anchor(SITE_AREA . '/master/masterprogramstudi/edit/' . $record->id, '<span class="icon-pencil"></span>' .  $record->kode_fakultas); ?></td>
				<?php else : ?>
					<td><?php e($record->kode_fakultas); ?></td>
				<?php endif; ?>
					<td><?php e($record->kode_prodi) ?></td>
					<td><?php e($record->kode_jenjang_studi) ?></td>
					<td><?php e($record->nama_prodi) ?></td>
					<td><?php e($record->semester_awal) ?></td>
					<td><?php e($record->no_sk_dikti) ?></td>
					<td><?php e($record->tgl_sk_dikti) ?></td>
					<td><?php e($record->tgl_akhir_sk_dikti) ?></td>
					<td><?php e($record->jml_sks_lulus) ?></td>
					<td><?php e($record->kode_status) ?></td>
					<td><?php e($record->tahun_semester_mulai) ?></td>
					<td><?php e($record->email_prodi) ?></td>
					<td><?php e($record->tgl_pendirian_program_studi) ?></td>
					<td><?php e($record->no_sk_akreditasi) ?></td>
					<td><?php e($record->tgl_sk_akreditasi) ?></td>
					<td><?php e($record->tgl_akhir_sk_akreditasi) ?></td>
					<td><?php e($record->kode_status_akreditasi) ?></td>
					<td><?php e($record->frekuensi_kurikulum) ?></td>
					<td><?php e($record->pelaksanaan_kurikulum) ?></td>
					<td><?php e($record->nidn_ketua_prodi) ?></td>
					<td><?php e($record->telp_ketua_prodi) ?></td>
					<td><?php e($record->fax_prodi) ?></td>
					<td><?php e($record->nama_operator) ?></td>
					<td><?php e($record->hp_operator) ?></td>
					<td><?php e($record->photo_prodi) ?></td>
					<td><?php e($record->telepon_program_studi) ?></td>
				</tr>
				<?php
					endforeach;
				else:
				?>
				<tr>
					<td colspan="<?php echo $num_columns; ?>">No records found that match your selection.</td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
	<?php echo form_close(); ?>
	 <div class="pagination pagination-right"> 
		
		<?php echo $this->pagination->create_links(); ?>
	</div>
</div>