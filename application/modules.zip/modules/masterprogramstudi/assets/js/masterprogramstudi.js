$('#masterprogramstudi_tgl_sk_dikti').datepicker({ dateFormat: 'yy-mm-dd'});
$('#masterprogramstudi_tgl_akhir_sk_dikti').datepicker({ dateFormat: 'yy-mm-dd'});
$('#masterprogramstudi_tgl_pendirian_program_studi').datepicker({ dateFormat: 'yy-mm-dd'});
$('#masterprogramstudi_tgl_sk_akreditasi').datepicker({ dateFormat: 'yy-mm-dd'});
$('#masterprogramstudi_tgl_akhir_sk_akreditasi').datepicker({ dateFormat: 'yy-mm-dd'});
