<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['masterprogramstudi_manage']			= 'Manage MasterProgramStudi';
$lang['masterprogramstudi_edit']				= 'Edit';
$lang['masterprogramstudi_true']				= 'True';
$lang['masterprogramstudi_false']				= 'False';
$lang['masterprogramstudi_create']			= 'Create';
$lang['masterprogramstudi_list']				= 'List';
$lang['masterprogramstudi_new']				= 'New';
$lang['masterprogramstudi_edit_text']			= 'Edit this to suit your needs';
$lang['masterprogramstudi_no_records']		= 'There aren\'t any masterprogramstudi in the system.';
$lang['masterprogramstudi_create_new']		= 'Create a new MasterProgramStudi.';
$lang['masterprogramstudi_create_success']	= 'MasterProgramStudi successfully created.';
$lang['masterprogramstudi_create_failure']	= 'There was a problem creating the masterprogramstudi: ';
$lang['masterprogramstudi_create_new_button']	= 'Create New MasterProgramStudi';
$lang['masterprogramstudi_invalid_id']		= 'Invalid MasterProgramStudi ID.';
$lang['masterprogramstudi_edit_success']		= 'MasterProgramStudi successfully saved.';
$lang['masterprogramstudi_edit_failure']		= 'There was a problem saving the masterprogramstudi: ';
$lang['masterprogramstudi_delete_success']	= 'record(s) successfully deleted.';
$lang['masterprogramstudi_delete_failure']	= 'We could not delete the record: ';
$lang['masterprogramstudi_delete_error']		= 'You have not selected any records to delete.';
$lang['masterprogramstudi_actions']			= 'Actions';
$lang['masterprogramstudi_cancel']			= 'Cancel';
$lang['masterprogramstudi_delete_record']		= 'Delete this MasterProgramStudi';
$lang['masterprogramstudi_delete_confirm']	= 'Are you sure you want to delete this masterprogramstudi?';
$lang['masterprogramstudi_edit_heading']		= 'Edit MasterProgramStudi';

// Create/Edit Buttons
$lang['masterprogramstudi_action_edit']		= 'Save MasterProgramStudi';
$lang['masterprogramstudi_action_create']		= 'Create MasterProgramStudi';

// Activities
$lang['masterprogramstudi_act_create_record']	= 'Created record with ID';
$lang['masterprogramstudi_act_edit_record']	= 'Updated record with ID';
$lang['masterprogramstudi_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['masterprogramstudi_column_created']	= 'Created';
$lang['masterprogramstudi_column_deleted']	= 'Deleted';
$lang['masterprogramstudi_column_modified']	= 'Modified';
