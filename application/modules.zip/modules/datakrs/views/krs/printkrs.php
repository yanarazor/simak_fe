<style>
 
@media print {
    body {
		font-weight:normal;
      font-style:normal;
      font-variant:normal;
	
		font-size : 12pt;
		line-height:20px;
    }
	
	@font-face {
		font-family: "Times New Roman", Times, serif;
		/*
		src: url('../font/DOTMATRI.eot');
		src: url('../font/DOTMATRI.eot?#iefix') format('embedded-opentype'),
			 url('../font/DOTMATRI.woff') format('woff'),
			 url('../font/DOTMATRI.ttf') format('truetype'),
			 url('../font/DOTMATRI.svg#proxima_nova_rgregular') format('svg');
			 */
		font-weight: normal;
		font-style: normal;

	}
	 
   table {
	 border-collapse: collapse;
   }
	/* use this class to attach this font to any element i.e. <p class="fontsforweb_fontid_507">Text with this font applied</p> */
	.fontsforweb_fontid_507 {
		font-family: 'DOTMATRI' !important;
	}
	.btnprint{
		display: none;
	}
}
</style>
<br/>
<?php
	$this->load->library('convert');
	$convert = new convert();
  // Change the css classes to suit your needs
if( isset($datamahasiswa) ) {
//    $datamahasiswa = (array)$datamahasiswa;
}
$id = isset($datakrs['id']) ? $datakrs['id'] : '';
?>

 <div style="margin-left:10px;margin-top:30px;"> 
    <table border="1" width="100%">
    	<tr>
        	<td width="270px" align="center">
            	 UNIVERSITAS MUHAMMADIYAH JAKARTA
            </td>
        </tr>
        <tr>
            <td align="center">
            	FAKULTAS <?php echo isset($datamahasiswa[0]->nama_fakultas) ? $datamahasiswa[0]->nama_fakultas : ""; ?>
            </td>
             
        </tr>
        <tr>
            <td align="center">
            	Jl. K. H. Ahmad Dahlan Cirendeu Ciputat Jakarta Selatan	
            </td>
             
        </tr>
        <tr>
            <td align="center">
            	***KARTU RENCANA STUDI***	
            </td>
             
        </tr>
        <tr>
            <td align="center">
            	Periode Semester Genap Tahun Akademik 
            </td>
             
        </tr>
        <tr>
            <td align="center">
            	PROGRAM STUDI <?php echo isset($datamahasiswa[0]->nama_prodi) ? $datamahasiswa[0]->nama_prodi : ""; ?>
            </td>
             
        </tr>
		
    </table>
    <table border="1" width="100%">
    	<tr>
        	<td align="center" width="40px">
            	 
            </td>
            <td  width="60px" >
            	 
            </td>
            <td align="center" width="50px">
            	 
            </td>
            <td align="center" width="50px">
            	 
            </td>
            <td align="left" width="600px" >
            	 Nama Mahasiswa : <?php echo isset($datamahasiswa[0]->nama_mahasiswa)?$datamahasiswa[0]->nama_mahasiswa:"" ?>
            </td>
            <td align="center" width="100px">
            	 
            </td>
            <td align="center" width="100px">
            	 
            </td>
            <td align="center" width="100px">
            	 
            </td>
        </tr>
        <tr>
        	<td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
            <td align="left">
            	  Nomor Pokok : <?php echo isset($datamahasiswa[0]->nim_mhs)?$datamahasiswa[0]->nim_mhs:"" ?>
            </td>
            <td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
        </tr>
       <tr>
        	<td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
            <td align="left">
            	 No HP :
            </td>
            <td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
            <td align="center">
            	 
            </td>
        </tr>
		
    </table>
	   <br>
    <table border="1" width="100%" style="height:150px">
	<tr>
		 <th  width="40px">
			 No
		 </th>
		 <th  width="60px" >
			 Semester
		 </th>
		 <th width="100px" >
			 Kode MK
		 </th>
		 <th width="600px" >
			 MATA KULIAH
		 </th>
		 
		 <th width="400px" >
			 SKS
		 </th>
		 <th>
			 Keterangan
		 </th>
    </tr>
    
    
    	 <?php 
    	 		$semester = 0;
    	 		
				if (isset($datakrs) && is_array($datakrs) && count($datakrs)) : 
					foreach ($datakrs as $record) :
					  if($record->semester!=$semester){
						 $semester = $record->semester;
					  }
					
					endforeach;
					 
				$no = 1;
					foreach ($datakrs as $record) :
					 if($record->semester!=$semester){
						$semester = $record->semester;
					 }
				?> 
				  <tr>
					  <td valign="top" align="center">  
						  <?php
						  echo $no;
						  ?>.
					  </td>
					  <td valign="top">
					  	<?php
					  	
					  	?>
						  <?php echo isset( $semester) ? $semester : ''; ?>
					  </td>
			 			<td valign="top">
						  <?php echo isset( $record->kode_mata_kuliah) ? $record->kode_mata_kuliah : ''; ?>
					  </td>
					   <td valign="top">
						  <?php echo isset( $record->nama_mata_kuliah) ? $record->nama_mata_kuliah : ''; ?>
					  </td>
					  <td width="40px" valign="top">
						  <?php echo isset( $record->sks) ? $record->sks : ''; ?>
					  </td>
					  <td width="600px" valign="top">
						  
					  </td>
					  
			
				  </tr>
        <?php 
        	$no++;
					endforeach; 
				endif;
				?>
				 
	</table>
	 
   <center>
   <a class="btn btn-large btnprint" target="_blank" href="<?php echo site_url(SITE_AREA .'/krs/datakrs/printkrs/'); echo isset($sms)? "/".$sms:""; ?>/print">

		Print

	</a>
	</center>
</div> 
