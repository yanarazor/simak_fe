<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Pengisian KRS - Mahasiswa',
	'name'			=> 'Pengisian KRS',
	'version'		=> '0.0.1',
	'author'		=> 'developer'
);