$('#datakrs_created_date').datepicker({ dateFormat: 'yy-mm-dd'});
