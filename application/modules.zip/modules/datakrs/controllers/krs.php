<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * krs controller
 */
class krs extends Admin_Controller
{

	//--------------------------------------------------------------------


	/**
	 * Constructor
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		$this->load->model('datakrs_model', null, true);
		$this->lang->load('datakrs');
		
		Assets::add_css('flick/jquery-ui-1.8.13.custom.css');
		Assets::add_js('jquery-ui-1.8.13.min.js');
		Template::set_block('sub_nav', 'krs/_sub_nav');

		Assets::add_module_js('datakrs', 'datakrs.js');
		
		//master matakuliah
		$this->load->model('mastermatakuliah/mastermatakuliah_model', null, true);
		$matakuliahs = $this->mastermatakuliah_model->find_all();
		Template::set('matakuliahs', $matakuliahs);
		$this->load->model('mastermahasiswa/mastermahasiswa_model', null, true);
		
		Assets::add_css('flick/jquery-ui-1.8.13.custom.css');
		Assets::add_js('jquery-ui-1.8.13.min.js');
		Assets::add_css('fancybox/jquery.fancybox-1.3.4.css');
		Assets::add_js('fancybox/jquery.fancybox-1.3.4.js');
		
		//master pilihan
		$this->load->model('pilihan/pilihan_model', null, true);
		$pilihansemester = $this->pilihan_model->find_all("sms");
		Template::set('pilihansemesters', $pilihansemester);
		
		$jenjangs = $this->pilihan_model->find_all("01");
		Template::set('jenjangs', $jenjangs);
		
		//master Dosen
		$this->load->model('masterdosen/masterdosen_model', null, true);
		$dosens = $this->masterdosen_model->find_all();
		Template::set('dosens', $dosens);
	}

	//--------------------------------------------------------------------


	/**
	 * Displays a list of form data.
	 *
	 * @return void
	 */
	public function index()
	{
		$this->auth->restrict('DataKrs.Krs.View');
		
		// Deleting anything?
		if (isset($_POST['delete']))
		{
			$checked = $this->input->post('checked');

			if (is_array($checked) && count($checked))
			{
				$result = FALSE;
				foreach ($checked as $pid)
				{
					$result = $this->datakrs_model->delete($pid);
				}

				if ($result)
				{
					Template::set_message(count($checked) .' '. lang('datakrs_delete_success'), 'success');
				}
				else
				{
					Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
				}
			}
		}
		$sms = $this->input->get('sms');
		$kode_mk = $this->input->get('kode_mk');
		$mhs = $this->input->get('mhs');
		
		$this->load->library('pagination');
		$total = $this->datakrs_model->rekap_count($sms,$this->current_user->nim);
		$offset = $this->input->get('per_page');
		$limit = $this->settings_lib->item('site.list_limit');

		$this->pager['base_url'] 			= current_url()."?sms=".$sms."&kode_mk=".$kode_mk."&mhs=".$mhs;
		$this->pager['total_rows'] 			= $total;
		$this->pager['per_page'] 			= $limit;
		$this->pager['page_query_string']	= TRUE;
		$this->pagination->initialize($this->pager);
		$records = $this->datakrs_model->limit($limit, $offset)->rekap($sms,$this->current_user->nim);

		Template::set('records', $records);
		Template::set('total', $total);
		
		Template::set('sms', $sms);
		
		Template::set('kode_mk', $kode_mk);
		Template::set('mhs', $mhs);
		Template::set('toolbar_title', '&nbsp;&nbsp; Pengelolaan Kartu Rencana Studi Mahasiswa');
		Template::render();
	}

	public function detil()
	{
		$sms = $this->uri->segment(5);
		 
		// Deleting anything?
		if (isset($_POST['delete']))
		{
			$checked = $this->input->post('checked');

			if (is_array($checked) && count($checked))
			{
				$result = FALSE;
				foreach ($checked as $pid)
				{
					$result = $this->datakrs_model->delete($pid);
				}

				if ($result)
				{
					Template::set_message(count($checked) .' '. lang('datakrs_delete_success'), 'success');
				}
				else
				{
					Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
				}
			}
		}
		$kode_mk = $this->input->get('kode_mk');
		$mhs = $this->current_user->nim;
		 
		
		$this->load->library('pagination');
		$total = $this->datakrs_model->count_all($sms,$kode_mk,$mhs);
		$offset = $this->input->get('per_page');
		$limit = $this->settings_lib->item('site.list_limit');

		$this->pager['base_url'] 			= current_url()."?sms=".$sms."&kode_mk=".$kode_mk."&mhs=".$mhs;
		$this->pager['total_rows'] 			= $total;
		$this->pager['per_page'] 			= $limit;
		$this->pager['page_query_string']	= TRUE;
		$this->pagination->initialize($this->pager);
		$records = $this->datakrs_model->limit($limit, $offset)->find_all($sms,$kode_mk,$mhs);

		Template::set('records', $records);
		Template::set('total', $total);
		
		Template::set('sms', $sms);
		
		Template::set('kode_mk', $kode_mk);
		Template::set('mhs', $mhs);
		Template::set('toolbar_title', 'Manage KRS');
		Template::render();
	}

	public function listdata()
	{

		// Deleting anything?
		if (isset($_POST['delete']))
		{
			$checked = $this->input->post('checked');

			if (is_array($checked) && count($checked))
			{
				$result = FALSE;
				foreach ($checked as $pid)
				{
					$result = $this->datakrs_model->delete($pid);
				}

				if ($result)
				{
					Template::set_message(count($checked) .' '. lang('datakrs_delete_success'), 'success');
				}
				else
				{
					Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
				}
			}
		}
		$sms = $this->input->get('sms');
		$kode_mk = $this->input->get('kode_mk');
		$mhs = $this->input->get('mhs');
		 
		
		$this->load->library('pagination');
		$total = $this->datakrs_model->count_all($sms,$kode_mk,$mhs);
		$offset = $this->input->get('per_page');
		$limit = $this->settings_lib->item('site.list_limit');

		$this->pager['base_url'] 			= current_url()."?sms=".$sms."&kode_mk=".$kode_mk."&mhs=".$mhs;
		$this->pager['total_rows'] 			= $total;
		$this->pager['per_page'] 			= $limit;
		$this->pager['page_query_string']	= TRUE;
		$this->pagination->initialize($this->pager);
		$records = $this->datakrs_model->limit($limit, $offset)->find_all($sms,$kode_mk,$mhs);

		Template::set('records', $records);
		Template::set('total', $total);
		
		Template::set('sms', $sms);
		
		Template::set('kode_mk', $kode_mk);
		Template::set('mhs', $mhs);
		Template::set('toolbar_title', 'Manage KRS');
		Template::render();
	}
	
	//--------------------------------------------------------------------


	/**
	 * Creates a DataKrs object.
	 *
	 * @return void
	 */
	public function create()
	{
		$this->auth->restrict('DataKrs.Krs.Create');

		if (isset($_POST['save']))
		{
			if ($insert_id = $this->save_datakrs())
			{
				// Log the activity
				log_activity($this->current_user->id, lang('datakrs_act_create_record') .': '. $insert_id .' : '. $this->input->ip_address(), 'datakrs');

				Template::set_message(lang('datakrs_create_success'), 'success');
				redirect(SITE_AREA .'/krs/datakrs');
			}
			else
			{
				Template::set_message(lang('datakrs_create_failure') . $this->datakrs_model->error, 'error');
			}
		}
		Assets::add_module_js('datakrs', 'datakrs.js');

		Template::set('toolbar_title', lang('datakrs_create') . ' DataKrs');
		Template::render();
	}

	public function input()
	{
		//die($this->current_user->nim." nim");
		$this->auth->restrict('DataKrs.Krs.Input');
		$this->load->model('mastermahasiswa/mastermahasiswa_model', null, true);
		$recordmahasiswa = $this->mastermahasiswa_model->get_by_nim($this->current_user->nim); 
		$sms = "1";
		$kode_prodi = "";
		if($recordmahasiswa){
		//print_r($recordmahasiswa);
				$sms = $recordmahasiswa[0]->semester;
				$kode_prodi = $recordmahasiswa[0]->kode_prodi;
		}
		// cek pembayaran apakah sudah 
		$status_bayar = "0";
		$this->load->model('konfirmasipembayaran/konfirmasipembayaran_model', null, true);
		if($this->konfirmasipembayaran_model->cekpembayaran($sms,$this->current_user->nim)>0)
		{
			$status_bayar = "1";
		} else{
			$status_bayar = "0";
		}
		//die($status_bayar);
		Template::set('status_bayar', $status_bayar);
		Template::set('kode_prodi', $kode_prodi);
		
	 	//die($sms."ini");
		$recordmks = $this->mastermatakuliah_model->find_by_ditawarkan($sms,$kode_prodi); 
		$total = 0;
		if(isset($recordmks) && is_array($recordmks) && count($recordmks))
			$total =  count($recordmks);
		Template::set('recordmks', $recordmks);
		Template::set('total',$total);
		Template::set('sms', $sms);
		
		if (isset($_POST['ambil']))
		{
			$checked = $this->input->post('checked');
			$sudahada = 0;
			$berhasil = 0;
			if (is_array($checked) && count($checked))
			{
			//die($sms." sks");
				$result = FALSE;
				foreach ($checked as $pid)
				{
					//echo $this->input->post('kodemk_'.$pid)."<br>";]
					//die($this->datakrs_model->isuniq_mhs($sms,$this->input->post('kodemk_'.$pid),$this->current_user->nim)." ini");
					if($this->datakrs_model->isuniq_mhs($sms,$this->input->post('kodemk_'.$pid),$this->current_user->nim)>0){
						$sudahada = $sudahada+1;
					}else{
						$berhasil = $berhasil+1;
						 
						$result = $this->save_datakrs($this->input->post('kodemk_'.$pid),$this->input->post('mksks_'.$pid),$this->current_user->nim,"",$sms);
					}
					//$kode_mk="",$sks="",$mahasiswa="",$kode_dosen="",$semester=""
				}

				if ($result)
				{
					Template::set_message($berhasil .' Mata kuliah sudah di tambahkan pada krs anda , Gagal :'.$sudahada, 'success');
				}
				else
				{
					Template::set_message($berhasil .' Mata kuliah tambahkan pada krs anda , Gagal :'.$sudahada.' Karena data mata kuliah sudah dimasukan' . $this->datakrs_model->error, 'error');
				}
			}
		}
		$recordkrss = $this->datakrs_model->find_all($sms,"",$this->current_user->nim);
		$jsonkrs[] =array();
		if (isset($recordkrss) && is_array($recordkrss) && count($recordkrss)) :
		foreach ($recordkrss as $record) : 
			$jsonkrs['idkrs'][$record->kode_mk] = $record->id;
			$jsonkrs['kode_mk'][$record->kode_mk] = $record->kode_mk;
			//die($record->kode_mk);
			$jsonkrs['sks'][$record->kode_mk] = $record->sks;
			$jsonkrs['kode_jadwal'][$record->kode_mk] = $record->kode_jadwal;
			$jsonkrs['semester'][$record->kode_mk] = $record->semester;
		endforeach;
		endif;
		Template::set('recordkrss', $recordkrss);
		Template::set('jsonkrs', $jsonkrs);
		//print_r($jsonkrs);
		//die();
		
		Assets::add_module_js('datakrs', 'datakrs.js');

		Template::set('toolbar_title', lang('datakrs_create') . ' DataKrs');
		Template::render();
	}

	public function printkrs()
	{
		$sms = $this->uri->segment(5);
		$mode = $this->uri->segment(6); 
		if (empty($sms))
		{
			Template::set_message("Semua Semester.", 'warning');
			 
		}
		Template::set('sms', $sms);
		$datakrs = $this->datakrs_model->find_all($sms,"",$this->current_user->nim);
		Template::set('datakrs', $datakrs);
		
		//detil mahasiswa
		$datamahasiswa = $this->mastermahasiswa_model->find_detil($this->current_user->nim);
		Template::set('datamahasiswa', $datamahasiswa);
		//print_r($datamahasiswa);
		//die();
		//die();
		Template::set_view('krs/printkrs');
		
		if($mode=="print"){
			//Assets::add_css('style.css');  
			Template::set_theme('print');
		}
		Template::set('toolbar_title', 'Print KRS');
		Template::render();
	}

	public function updatekrs()
	{
		$kode_jadwal = $this->input->get('kode_jadwal');
		$id_krs = $this->input->get('id_krs');
		$kelas = $this->input->get('kelas');
		
		$this->load->model('jadwal/jadwal_model', null, true);
		$jadwal = $this->jadwal_model->find($kode_jadwal);
		 
		$this->update_krs("","","",$jadwal->kode_dosen,"",$kode_jadwal,$kelas,'update', $id_krs);
		
		die();
	}
	//--------------------------------------------------------------------


	/**
	 * Allows editing of DataKrs data.
	 *
	 * @return void
	 */
	public function edit()
	{
		$id = $this->uri->segment(5);

		if (empty($id))
		{
			Template::set_message(lang('datakrs_invalid_id'), 'error');
			redirect(SITE_AREA .'/krs/datakrs');
		}

		if (isset($_POST['save']))
		{
			$this->auth->restrict('DataKrs.Krs.Edit');

			if ($this->edit_datakrs('update', $id))
			{
				// Log the activity
				log_activity($this->current_user->id, lang('datakrs_act_edit_record') .': '. $id .' : '. $this->input->ip_address(), 'datakrs');

				Template::set_message(lang('datakrs_edit_success'), 'success');
			}
			else
			{
				Template::set_message(lang('datakrs_edit_failure') . $this->datakrs_model->error, 'error');
			}
		}
		else if (isset($_POST['delete']))
		{
			$this->auth->restrict('DataKrs.Krs.Delete');

			if ($this->datakrs_model->delete($id))
			{
				// Log the activity
				log_activity($this->current_user->id, lang('datakrs_act_delete_record') .': '. $id .' : '. $this->input->ip_address(), 'datakrs');

				Template::set_message(lang('datakrs_delete_success'), 'success');

				redirect(SITE_AREA .'/krs/datakrs');
			}
			else
			{
				Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
			}
		}
		Template::set('datakrs', $this->datakrs_model->find($id));
		Template::set('toolbar_title', lang('datakrs_edit') .' DataKrs');
		Template::render();
	}

	//--------------------------------------------------------------------

	//--------------------------------------------------------------------
	// !PRIVATE METHODS
	//--------------------------------------------------------------------

	/**
	 * Summary
	 *
	 * @param String $type Either "insert" or "update"
	 * @param Int	 $id	The ID of the record to update, ignored on inserts
	 *
	 * @return Mixed    An INT id for successful inserts, TRUE for successful updates, else FALSE
	 */
	private function save_datakrs($kode_mk="",$sks="",$mahasiswa="",$kode_dosen="",$semester="",$type='insert', $id=0)
	{
		if ($type == 'update')
		{
			$_POST['id'] = $id;
		}

		// make sure we only pass in the fields we want
		
		$data = array();
		$data['kode_mk']        = $kode_mk;
		$data['sks']        	= $sks;
		$data['mahasiswa']      = $mahasiswa;
		$data['kode_dosen']     = $kode_dosen;
		$data['semester']       = $semester;
		//$data['kode_jadwal']        = $this->input->post('datakrs_kode_jadwal');
		//$data['nilai_angka']        = $this->input->post('datakrs_nilai_angka');
		//$data['nilai_huruf']        = $this->input->post('datakrs_nilai_huruf');
		$data['created_date']        = date("Y-m-d");
		// $this->input->post('datakrs_created_date') ? $this->input->post('datakrs_created_date') : '0000-00-00';

		if ($type == 'insert')
		{
			$id = $this->datakrs_model->insert($data);

			if (is_numeric($id))
			{
				$return = $id;
			}
			else
			{
				$return = FALSE;
			}
		}
		elseif ($type == 'update')
		{
			$return = $this->datakrs_model->update($id, $data);
		}

		return $return;
	}
	private function edit_datakrs($type='insert', $id=0)
	{
		if ($type == 'update')
		{
			$_POST['id'] = $id;
		}

		// make sure we only pass in the fields we want
		
		$data = array();
		$data['kode_mk']       	 = $this->input->post('datakrs_kode_mk');
		$data['sks']      		  = $this->input->post('datakrs_sks');
		$data['mahasiswa']        = $this->input->post('datakrs_mahasiswa');
		$data['kode_dosen']        = $this->input->post('datakrs_kode_dosen');
		$data['semester']        = $this->input->post('datakrs_semester');
		$data['kode_jadwal']        = $this->input->post('datakrs_kode_jadwal');
		$data['nilai_angka']        = $this->input->post('datakrs_nilai_angka');
		$data['nilai_huruf']        = $this->input->post('datakrs_nilai_huruf');
		//$data['created_date']        = date("Y-m-d");// $this->input->post('datakrs_created_date') ? $this->input->post('datakrs_created_date') : '0000-00-00';

		if ($type == 'insert')
		{
			$id = $this->datakrs_model->insert($data);

			if (is_numeric($id))
			{
				$return = $id;
			}
			else
			{
				$return = FALSE;
			}
		}
		elseif ($type == 'update')
		{
			$return = $this->datakrs_model->update($id, $data);
		}

		return $return;
	}
	
	private function update_krs($kode_mk="",$sks="",$mahasiswa="",$kode_dosen="",$semester="",$kode_jadwal="",$kelas="",$type='insert', $id=0)
	{
		if ($type == 'update')
		{
			$_POST['id'] = $id;
		}

		// make sure we only pass in the fields we want
		
		$data = array();
		if($kode_mk!="")
			$data['kode_mk']        = $kode_mk;
		if($sks!="")
			$data['sks']        = $sks;
		if($mahasiswa!="")
			$data['mahasiswa']        = $mahasiswa;
		if($kode_dosen!="")
			$data['kode_dosen']        = $kode_dosen;
		if($semester!="")
			$data['semester']        = $semester;
		if($kode_jadwal!="")
			$data['kode_jadwal']        = $kode_jadwal;
		if($kelas!="")
			$data['kelas']        = $kelas;
		if ($type == 'insert')
		{
			$id = $this->datakrs_model->insert($data);

			if (is_numeric($id))
			{
				$return = $id;
			}
			else
			{
				$return = FALSE;
			}
		}
		elseif ($type == 'update')
		{
			$return = $this->datakrs_model->update($id, $data);
		}

		return $return;
	}

	//--------------------------------------------------------------------


}