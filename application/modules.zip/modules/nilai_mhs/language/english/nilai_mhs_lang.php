<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['nilai_mhs_manage']			= 'Manage Nilai Mhs';
$lang['nilai_mhs_edit']				= 'Edit';
$lang['nilai_mhs_true']				= 'True';
$lang['nilai_mhs_false']				= 'False';
$lang['nilai_mhs_create']			= 'Create';
$lang['nilai_mhs_list']				= 'List';
$lang['nilai_mhs_new']				= 'New';
$lang['nilai_mhs_edit_text']			= 'Edit this to suit your needs';
$lang['nilai_mhs_no_records']		= 'There aren\'t any nilai_mhs in the system.';
$lang['nilai_mhs_create_new']		= 'Create a new Nilai Mhs.';
$lang['nilai_mhs_create_success']	= 'Nilai Mhs successfully created.';
$lang['nilai_mhs_create_failure']	= 'There was a problem creating the nilai_mhs: ';
$lang['nilai_mhs_create_new_button']	= 'Create New Nilai Mhs';
$lang['nilai_mhs_invalid_id']		= 'Invalid Nilai Mhs ID.';
$lang['nilai_mhs_edit_success']		= 'Nilai Mhs successfully saved.';
$lang['nilai_mhs_edit_failure']		= 'There was a problem saving the nilai_mhs: ';
$lang['nilai_mhs_delete_success']	= 'record(s) successfully deleted.';
$lang['nilai_mhs_delete_failure']	= 'We could not delete the record: ';
$lang['nilai_mhs_delete_error']		= 'You have not selected any records to delete.';
$lang['nilai_mhs_actions']			= 'Actions';
$lang['nilai_mhs_cancel']			= 'Cancel';
$lang['nilai_mhs_delete_record']		= 'Delete this Nilai Mhs';
$lang['nilai_mhs_delete_confirm']	= 'Are you sure you want to delete this nilai_mhs?';
$lang['nilai_mhs_edit_heading']		= 'Edit Nilai Mhs';

// Create/Edit Buttons
$lang['nilai_mhs_action_edit']		= 'Save Nilai Mhs';
$lang['nilai_mhs_action_create']		= 'Create Nilai Mhs';

// Activities
$lang['nilai_mhs_act_create_record']	= 'Created record with ID';
$lang['nilai_mhs_act_edit_record']	= 'Updated record with ID';
$lang['nilai_mhs_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['nilai_mhs_column_created']	= 'Created';
$lang['nilai_mhs_column_deleted']	= 'Deleted';
$lang['nilai_mhs_column_modified']	= 'Modified';
