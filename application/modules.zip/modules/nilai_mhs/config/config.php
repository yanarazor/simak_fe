<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Input Nilai Mahasiswa',
	'name'		=> 'Nilai Mhs',
	'version'		=> '0.0.1',
	'author'		=> 'yanarazor update'
);