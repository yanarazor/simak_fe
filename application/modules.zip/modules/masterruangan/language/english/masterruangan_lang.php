<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['masterruangan_manage']			= 'Manage MasterRuangan';
$lang['masterruangan_edit']				= 'Edit';
$lang['masterruangan_true']				= 'True';
$lang['masterruangan_false']				= 'False';
$lang['masterruangan_create']			= 'Create';
$lang['masterruangan_list']				= 'List';
$lang['masterruangan_new']				= 'New';
$lang['masterruangan_edit_text']			= 'Edit this to suit your needs';
$lang['masterruangan_no_records']		= 'There aren\'t any masterruangan in the system.';
$lang['masterruangan_create_new']		= 'Create a new MasterRuangan.';
$lang['masterruangan_create_success']	= 'MasterRuangan successfully created.';
$lang['masterruangan_create_failure']	= 'There was a problem creating the masterruangan: ';
$lang['masterruangan_create_new_button']	= 'Create New MasterRuangan';
$lang['masterruangan_invalid_id']		= 'Invalid MasterRuangan ID.';
$lang['masterruangan_edit_success']		= 'MasterRuangan successfully saved.';
$lang['masterruangan_edit_failure']		= 'There was a problem saving the masterruangan: ';
$lang['masterruangan_delete_success']	= 'record(s) successfully deleted.';
$lang['masterruangan_delete_failure']	= 'We could not delete the record: ';
$lang['masterruangan_delete_error']		= 'You have not selected any records to delete.';
$lang['masterruangan_actions']			= 'Actions';
$lang['masterruangan_cancel']			= 'Cancel';
$lang['masterruangan_delete_record']		= 'Delete this MasterRuangan';
$lang['masterruangan_delete_confirm']	= 'Are you sure you want to delete this masterruangan?';
$lang['masterruangan_edit_heading']		= 'Edit MasterRuangan';

// Create/Edit Buttons
$lang['masterruangan_action_edit']		= 'Save MasterRuangan';
$lang['masterruangan_action_create']		= 'Create MasterRuangan';

// Activities
$lang['masterruangan_act_create_record']	= 'Created record with ID';
$lang['masterruangan_act_edit_record']	= 'Updated record with ID';
$lang['masterruangan_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['masterruangan_column_created']	= 'Created';
$lang['masterruangan_column_deleted']	= 'Deleted';
$lang['masterruangan_column_modified']	= 'Modified';
