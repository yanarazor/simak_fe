$('#masterbadanhukum_tgl_akta').datepicker({ dateFormat: 'yy-mm-dd'});
$('#masterbadanhukum_tgl_pengesahan').datepicker({ dateFormat: 'yy-mm-dd'});
$('#masterbadanhukum_tgl_pendirian').datepicker({ dateFormat: 'yy-mm-dd'});
