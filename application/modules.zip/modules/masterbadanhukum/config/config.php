<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Master Badan Hukum',
	'name'		=> 'Badan Hukum',
	'version'		=> '0.0.1',
	'author'		=> 'developer'
);