$('#konfirmasipembayaran_tanggal').datepicker({ dateFormat: 'yy-mm-dd'});
$('#konfirmasipembayaran_date_created').datepicker({ dateFormat: 'yy-mm-dd'});
