<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['konfirmasi_pembayaran_manage']			= 'Manage Konfirmasi Pembayaran';
$lang['konfirmasi_pembayaran_edit']				= 'Edit';
$lang['konfirmasi_pembayaran_true']				= 'True';
$lang['konfirmasi_pembayaran_false']				= 'False';
$lang['konfirmasi_pembayaran_create']			= 'Create';
$lang['konfirmasi_pembayaran_list']				= 'List';
$lang['konfirmasi_pembayaran_new']				= 'New';
$lang['konfirmasi_pembayaran_edit_text']			= 'Edit this to suit your needs';
$lang['konfirmasi_pembayaran_no_records']		= 'There aren\'t any konfirmasi_pembayaran in the system.';
$lang['konfirmasi_pembayaran_create_new']		= 'Create a new Konfirmasi Pembayaran.';
$lang['konfirmasi_pembayaran_create_success']	= 'Konfirmasi Pembayaran successfully created.';
$lang['konfirmasi_pembayaran_create_failure']	= 'There was a problem creating the konfirmasi_pembayaran: ';
$lang['konfirmasi_pembayaran_create_new_button']	= 'Create New Konfirmasi Pembayaran';
$lang['konfirmasi_pembayaran_invalid_id']		= 'Invalid Konfirmasi Pembayaran ID.';
$lang['konfirmasi_pembayaran_edit_success']		= 'Konfirmasi Pembayaran successfully saved.';
$lang['konfirmasi_pembayaran_edit_failure']		= 'There was a problem saving the konfirmasi_pembayaran: ';
$lang['konfirmasi_pembayaran_delete_success']	= 'record(s) successfully deleted.';
$lang['konfirmasi_pembayaran_delete_failure']	= 'We could not delete the record: ';
$lang['konfirmasi_pembayaran_delete_error']		= 'You have not selected any records to delete.';
$lang['konfirmasi_pembayaran_actions']			= 'Actions';
$lang['konfirmasi_pembayaran_cancel']			= 'Cancel';
$lang['konfirmasi_pembayaran_delete_record']		= 'Delete this Konfirmasi Pembayaran';
$lang['konfirmasi_pembayaran_delete_confirm']	= 'Are you sure you want to delete this konfirmasi_pembayaran?';
$lang['konfirmasi_pembayaran_edit_heading']		= 'Edit Konfirmasi Pembayaran';

// Create/Edit Buttons
$lang['konfirmasi_pembayaran_action_edit']		= 'Save Konfirmasi Pembayaran';
$lang['konfirmasi_pembayaran_action_create']		= 'Create Konfirmasi Pembayaran';

// Activities
$lang['konfirmasi_pembayaran_act_create_record']	= 'Created record with ID';
$lang['konfirmasi_pembayaran_act_edit_record']	= 'Updated record with ID';
$lang['konfirmasi_pembayaran_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['konfirmasi_pembayaran_column_created']	= 'Created';
$lang['konfirmasi_pembayaran_column_deleted']	= 'Deleted';
$lang['konfirmasi_pembayaran_column_modified']	= 'Modified';
