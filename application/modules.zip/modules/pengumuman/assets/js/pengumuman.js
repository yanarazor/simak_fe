$('#pengumuman_tgl_pengumuman').datepicker({ dateFormat: 'yy-mm-dd'});
$('#pengumuman_tgl_awal').datepicker({ dateFormat: 'yy-mm-dd'});
$('#pengumuman_tgl_akhir').datepicker({ dateFormat: 'yy-mm-dd'});
