<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['konfirmasipembayaran_manage']			= 'Manage KonfirmasiPembayaran';
$lang['konfirmasipembayaran_edit']				= 'Edit';
$lang['konfirmasipembayaran_true']				= 'True';
$lang['konfirmasipembayaran_false']				= 'False';
$lang['konfirmasipembayaran_create']			= 'Create';
$lang['konfirmasipembayaran_list']				= 'List';
$lang['konfirmasipembayaran_new']				= 'New';
$lang['konfirmasipembayaran_edit_text']			= 'Edit this to suit your needs';
$lang['konfirmasipembayaran_no_records']		= 'There aren\'t any konfirmasipembayaran in the system.';
$lang['konfirmasipembayaran_create_new']		= 'Create a new KonfirmasiPembayaran.';
$lang['konfirmasipembayaran_create_success']	= 'KonfirmasiPembayaran successfully created.';
$lang['konfirmasipembayaran_create_failure']	= 'There was a problem creating the konfirmasipembayaran: ';
$lang['konfirmasipembayaran_create_new_button']	= 'Create New KonfirmasiPembayaran';
$lang['konfirmasipembayaran_invalid_id']		= 'Invalid KonfirmasiPembayaran ID.';
$lang['konfirmasipembayaran_edit_success']		= 'KonfirmasiPembayaran successfully saved.';
$lang['konfirmasipembayaran_edit_failure']		= 'There was a problem saving the konfirmasipembayaran: ';
$lang['konfirmasipembayaran_delete_success']	= 'record(s) successfully deleted.';
$lang['konfirmasipembayaran_delete_failure']	= 'We could not delete the record: ';
$lang['konfirmasipembayaran_delete_error']		= 'You have not selected any records to delete.';
$lang['konfirmasipembayaran_actions']			= 'Actions';
$lang['konfirmasipembayaran_cancel']			= 'Cancel';
$lang['konfirmasipembayaran_delete_record']		= 'Delete this KonfirmasiPembayaran';
$lang['konfirmasipembayaran_delete_confirm']	= 'Are you sure you want to delete this konfirmasipembayaran?';
$lang['konfirmasipembayaran_edit_heading']		= 'Edit KonfirmasiPembayaran';

// Create/Edit Buttons
$lang['konfirmasipembayaran_action_edit']		= 'Save KonfirmasiPembayaran';
$lang['konfirmasipembayaran_action_create']		= 'Create KonfirmasiPembayaran';

// Activities
$lang['konfirmasipembayaran_act_create_record']	= 'Created record with ID';
$lang['konfirmasipembayaran_act_edit_record']	= 'Updated record with ID';
$lang['konfirmasipembayaran_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['konfirmasipembayaran_column_created']	= 'Created';
$lang['konfirmasipembayaran_column_deleted']	= 'Deleted';
$lang['konfirmasipembayaran_column_modified']	= 'Modified';
