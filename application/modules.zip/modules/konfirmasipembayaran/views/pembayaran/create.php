<?php

$validation_errors = validation_errors();

if ($validation_errors) :
?>
<div class="alert alert-block alert-error fade in">
	<a class="close" data-dismiss="alert">&times;</a>
	<h4 class="alert-heading">Please fix the following errors:</h4>
	<?php echo $validation_errors; ?>
</div>
<?php
endif;

if (isset($konfirmasipembayaran))
{
	$konfirmasipembayaran = (array) $konfirmasipembayaran;
}
$id = isset($konfirmasipembayaran['id']) ? $konfirmasipembayaran['id'] : '';

?>
<div class="admin-box">
	 
	<?php echo form_open_multipart($this->uri->uri_string(), 'class="form-horizontal"'); ?>
		<fieldset>

			<div class="control-group <?php echo form_error('konfirmasipembayaran_nim') ? 'error' : ''; ?>">
				<?php echo form_label('Nim Mahasiswa'. lang('bf_form_label_required'), 'konfirmasipembayaran_nim', array('class' => 'control-label') ); ?>
				<div class='controls'>
					<input id='konfirmasipembayaran_nim' type='text' name='konfirmasipembayaran_nim' maxlength="20" value="<?php echo set_value('konfirmasipembayaran_nim', isset($konfirmasipembayaran['nim']) ? $konfirmasipembayaran['nim'] : ''); ?>" />
					<span class='help-inline'><?php echo form_error('konfirmasipembayaran_nim'); ?></span>
				</div>
			</div>

			<div class="control-group <?php echo form_error('pembayaran') ? 'error' : ''; ?>">
				<?php echo form_label('Untuk Pembayaran', 'konfirmasipembayaran_pembayaran', array('class' => 'control-label') ); ?>
				<div class='controls'>
					<input id='konfirmasipembayaran_pembayaran' type='text' name='konfirmasipembayaran_pembayaran' maxlength="30" value="<?php echo set_value('konfirmasipembayaran_pembayaran', isset($konfirmasipembayaran['pembayaran']) ? $konfirmasipembayaran['pembayaran'] : ''); ?>" />
					<span class='help-inline'><?php echo form_error('pembayaran'); ?></span>
				</div>
			</div>

			<div class="control-group <?php echo form_error('semester') ? 'error' : ''; ?>">
				<?php echo form_label('Semester', 'konfirmasipembayaran_semester', array('class' => 'control-label') ); ?>
				<div class='controls'>
					<input id='konfirmasipembayaran_semester' type='text' name='konfirmasipembayaran_semester' maxlength="5" value="<?php echo set_value('konfirmasipembayaran_semester', isset($konfirmasipembayaran['semester']) ? $konfirmasipembayaran['semester'] : ''); ?>" />
					<span class='help-inline'><?php echo form_error('semester'); ?></span>
				</div>
			</div>

			<div class="control-group <?php echo form_error('konfirmasipembayaran_jumlah') ? 'error' : ''; ?>">
				<?php echo form_label('Jumlah Bayar'. lang('bf_form_label_required'), 'konfirmasipembayaran_jumlah', array('class' => 'control-label') ); ?>
				<div class='controls'>
					<input id='konfirmasipembayaran_jumlah' type='text' name='konfirmasipembayaran_jumlah' maxlength="20" value="<?php echo set_value('konfirmasipembayaran_jumlah', isset($konfirmasipembayaran['jumlah']) ? $konfirmasipembayaran['jumlah'] : ''); ?>" />
					<span class='help-inline'><?php echo form_error('konfirmasipembayaran_jumlah'); ?></span>
				</div>
			</div>

			<div class="control-group <?php echo form_error('tanggal') ? 'error' : ''; ?>">
				<?php echo form_label('Tanggal Bayar', 'konfirmasipembayaran_tanggal', array('class' => 'control-label') ); ?>
				<div class='controls'>
					<input id='konfirmasipembayaran_tanggal' type='text' name='konfirmasipembayaran_tanggal'  value="<?php echo set_value('konfirmasipembayaran_tanggal', isset($konfirmasipembayaran['tanggal']) ? $konfirmasipembayaran['tanggal'] : ''); ?>" />
					<span class='help-inline'><?php echo form_error('tanggal'); ?></span>
				</div>
			</div>

			<div class="control-group <?php echo form_error('bank') ? 'error' : ''; ?>">
				<?php echo form_label('Bank', 'konfirmasipembayaran_bank', array('class' => 'control-label') ); ?>
				<div class='controls'>
					<input id='konfirmasipembayaran_bank' type='text' name='konfirmasipembayaran_bank' maxlength="20" value="<?php echo set_value('konfirmasipembayaran_bank', isset($konfirmasipembayaran['bank']) ? $konfirmasipembayaran['bank'] : ''); ?>" />
					<span class='help-inline'><?php echo form_error('bank'); ?></span>
				</div>
			</div>

			<div class="control-group <?php echo form_error('file') ? 'error' : ''; ?>">
				<?php echo form_label('Bukti Pembayaran', 'konfirmasipembayaran_file', array('class' => 'control-label') ); ?>
				<div class='controls'>
					<input type="file" class="span6" name="file_upload" id="file_upload" /> 
					<span class='help-inline'><?php echo form_error('file'); ?></span>
				</div>
			</div>

			<div class="control-group <?php echo form_error('keterangan') ? 'error' : ''; ?>">
				<?php echo form_label('Keterangan', 'konfirmasipembayaran_keterangan', array('class' => 'control-label') ); ?>
				<div class='controls'>
					<?php echo form_textarea( array( 'name' => 'konfirmasipembayaran_keterangan', 'id' => 'konfirmasipembayaran_keterangan','style'=>'width:550px', 'rows' => '5', 'cols' => '80', 'value' => set_value('konfirmasipembayaran_keterangan', isset($konfirmasipembayaran['keterangan']) ? $konfirmasipembayaran['keterangan'] : '') ) ); ?>
					<span class='help-inline'><?php echo form_error('keterangan'); ?></span>
				</div>
			</div>
 
			<div class="form-actions">
				<input type="submit" name="save" class="btn btn-primary" value="<?php echo lang('konfirmasipembayaran_action_create'); ?>"  />
				<?php echo lang('bf_or'); ?>
				<?php echo anchor(SITE_AREA .'/pembayaran/konfirmasipembayaran', lang('konfirmasipembayaran_cancel'), 'class="btn btn-warning"'); ?>
				
			</div>
		</fieldset>
    <?php echo form_close(); ?>
</div>
<script type="text/javascript">
 
	$(document).ready(function() {	  
	 
		$('#konfirmasipembayaran_keterangan').wysiwyg();	
		 
		
	}); 
</script>