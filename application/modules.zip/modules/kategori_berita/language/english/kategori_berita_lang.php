<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['kategori_berita_manage']			= 'Manage Kategori Berita';
$lang['kategori_berita_edit']				= 'Edit';
$lang['kategori_berita_true']				= 'True';
$lang['kategori_berita_false']				= 'False';
$lang['kategori_berita_create']			= 'Create';
$lang['kategori_berita_list']				= 'List';
$lang['kategori_berita_new']				= 'New';
$lang['kategori_berita_edit_text']			= 'Edit this to suit your needs';
$lang['kategori_berita_no_records']		= 'There aren\'t any kategori_berita in the system.';
$lang['kategori_berita_create_new']		= 'Create a new Kategori Berita.';
$lang['kategori_berita_create_success']	= 'Kategori Berita successfully created.';
$lang['kategori_berita_create_failure']	= 'There was a problem creating the kategori_berita: ';
$lang['kategori_berita_create_new_button']	= 'Create New Kategori Berita';
$lang['kategori_berita_invalid_id']		= 'Invalid Kategori Berita ID.';
$lang['kategori_berita_edit_success']		= 'Kategori Berita successfully saved.';
$lang['kategori_berita_edit_failure']		= 'There was a problem saving the kategori_berita: ';
$lang['kategori_berita_delete_success']	= 'record(s) successfully deleted.';
$lang['kategori_berita_delete_failure']	= 'We could not delete the record: ';
$lang['kategori_berita_delete_error']		= 'You have not selected any records to delete.';
$lang['kategori_berita_actions']			= 'Actions';
$lang['kategori_berita_cancel']			= 'Cancel';
$lang['kategori_berita_delete_record']		= 'Delete this Kategori Berita';
$lang['kategori_berita_delete_confirm']	= 'Are you sure you want to delete this kategori_berita?';
$lang['kategori_berita_edit_heading']		= 'Edit Kategori Berita';

// Create/Edit Buttons
$lang['kategori_berita_action_edit']		= 'Save Kategori Berita';
$lang['kategori_berita_action_create']		= 'Create Kategori Berita';

// Activities
$lang['kategori_berita_act_create_record']	= 'Created record with ID';
$lang['kategori_berita_act_edit_record']	= 'Updated record with ID';
$lang['kategori_berita_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['kategori_berita_column_created']	= 'Created';
$lang['kategori_berita_column_deleted']	= 'Deleted';
$lang['kategori_berita_column_modified']	= 'Modified';
