$('#mastermahasiswa_tgl_lahir').datepicker({ dateFormat: 'yy-mm-dd'});
$('#mastermahasiswa_tgl_masuk').datepicker({ dateFormat: 'yy-mm-dd'});
$('#mastermahasiswa_tgl_lulus').datepicker({ dateFormat: 'yy-mm-dd'});
