<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['masterdosen_manage']			= 'Manage MasterDosen';
$lang['masterdosen_edit']				= 'Edit';
$lang['masterdosen_true']				= 'True';
$lang['masterdosen_false']				= 'False';
$lang['masterdosen_create']			= 'Create';
$lang['masterdosen_list']				= 'List';
$lang['masterdosen_new']				= 'New';
$lang['masterdosen_edit_text']			= 'Edit this to suit your needs';
$lang['masterdosen_no_records']		= 'There aren\'t any masterdosen in the system.';
$lang['masterdosen_create_new']		= 'Create a new MasterDosen.';
$lang['masterdosen_create_success']	= 'MasterDosen successfully created.';
$lang['masterdosen_create_failure']	= 'There was a problem creating the masterdosen: ';
$lang['masterdosen_create_new_button']	= 'Create New MasterDosen';
$lang['masterdosen_invalid_id']		= 'Invalid MasterDosen ID.';
$lang['masterdosen_edit_success']		= 'MasterDosen successfully saved.';
$lang['masterdosen_edit_failure']		= 'There was a problem saving the masterdosen: ';
$lang['masterdosen_delete_success']	= 'record(s) successfully deleted.';
$lang['masterdosen_delete_failure']	= 'We could not delete the record: ';
$lang['masterdosen_delete_error']		= 'You have not selected any records to delete.';
$lang['masterdosen_actions']			= 'Actions';
$lang['masterdosen_cancel']			= 'Cancel';
$lang['masterdosen_delete_record']		= 'Delete this MasterDosen';
$lang['masterdosen_delete_confirm']	= 'Are you sure you want to delete this masterdosen?';
$lang['masterdosen_edit_heading']		= 'Edit MasterDosen';

// Create/Edit Buttons
$lang['masterdosen_action_edit']		= 'Save MasterDosen';
$lang['masterdosen_action_create']		= 'Create MasterDosen';

// Activities
$lang['masterdosen_act_create_record']	= 'Created record with ID';
$lang['masterdosen_act_edit_record']	= 'Updated record with ID';
$lang['masterdosen_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['masterdosen_column_created']	= 'Created';
$lang['masterdosen_column_deleted']	= 'Deleted';
$lang['masterdosen_column_modified']	= 'Modified';
