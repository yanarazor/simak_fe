<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['pilihan_manage']			= 'Manage Pilihan';
$lang['pilihan_edit']				= 'Edit';
$lang['pilihan_true']				= 'True';
$lang['pilihan_false']				= 'False';
$lang['pilihan_create']			= 'Create';
$lang['pilihan_list']				= 'List';
$lang['pilihan_new']				= 'New';
$lang['pilihan_edit_text']			= 'Edit this to suit your needs';
$lang['pilihan_no_records']		= 'There aren\'t any pilihan in the system.';
$lang['pilihan_create_new']		= 'Create a new Pilihan.';
$lang['pilihan_create_success']	= 'Pilihan successfully created.';
$lang['pilihan_create_failure']	= 'There was a problem creating the pilihan: ';
$lang['pilihan_create_new_button']	= 'Create New Pilihan';
$lang['pilihan_invalid_id']		= 'Invalid Pilihan ID.';
$lang['pilihan_edit_success']		= 'Pilihan successfully saved.';
$lang['pilihan_edit_failure']		= 'There was a problem saving the pilihan: ';
$lang['pilihan_delete_success']	= 'record(s) successfully deleted.';
$lang['pilihan_delete_failure']	= 'We could not delete the record: ';
$lang['pilihan_delete_error']		= 'You have not selected any records to delete.';
$lang['pilihan_actions']			= 'Actions';
$lang['pilihan_cancel']			= 'Cancel';
$lang['pilihan_delete_record']		= 'Delete this Pilihan';
$lang['pilihan_delete_confirm']	= 'Are you sure you want to delete this pilihan?';
$lang['pilihan_edit_heading']		= 'Edit Pilihan';

// Create/Edit Buttons
$lang['pilihan_action_edit']		= 'Save Pilihan';
$lang['pilihan_action_create']		= 'Create Pilihan';

// Activities
$lang['pilihan_act_create_record']	= 'Created record with ID';
$lang['pilihan_act_edit_record']	= 'Updated record with ID';
$lang['pilihan_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['pilihan_column_created']	= 'Created';
$lang['pilihan_column_deleted']	= 'Deleted';
$lang['pilihan_column_modified']	= 'Modified';
