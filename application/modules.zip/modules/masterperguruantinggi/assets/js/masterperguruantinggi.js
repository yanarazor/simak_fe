$('#masterperguruantinggi_tgl_akta_pt').datepicker({ dateFormat: 'yy-mm-dd'});
$('#masterperguruantinggi_tgl_pendirian_pt').datepicker({ dateFormat: 'yy-mm-dd'});
