<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Module Master Kelas',
	'name'			=> 'Kelas',
	'version'		=> '0.0.1',
	'author'		=> 'developer'
);