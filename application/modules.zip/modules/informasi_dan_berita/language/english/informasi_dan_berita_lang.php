<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['informasi_dan_berita_manage']			= 'Manage Informasi dan Berita';
$lang['informasi_dan_berita_edit']				= 'Edit';
$lang['informasi_dan_berita_true']				= 'True';
$lang['informasi_dan_berita_false']				= 'False';
$lang['informasi_dan_berita_create']			= 'Create';
$lang['informasi_dan_berita_list']				= 'List';
$lang['informasi_dan_berita_new']				= 'New';
$lang['informasi_dan_berita_edit_text']			= 'Edit this to suit your needs';
$lang['informasi_dan_berita_no_records']		= 'There aren\'t any informasi_dan_berita in the system.';
$lang['informasi_dan_berita_create_new']		= 'Create a new Informasi dan Berita.';
$lang['informasi_dan_berita_create_success']	= 'Informasi dan Berita successfully created.';
$lang['informasi_dan_berita_create_failure']	= 'There was a problem creating the informasi_dan_berita: ';
$lang['informasi_dan_berita_create_new_button']	= 'Create New Informasi dan Berita';
$lang['informasi_dan_berita_invalid_id']		= 'Invalid Informasi dan Berita ID.';
$lang['informasi_dan_berita_edit_success']		= 'Informasi dan Berita successfully saved.';
$lang['informasi_dan_berita_edit_failure']		= 'There was a problem saving the informasi_dan_berita: ';
$lang['informasi_dan_berita_delete_success']	= 'record(s) successfully deleted.';
$lang['informasi_dan_berita_delete_failure']	= 'We could not delete the record: ';
$lang['informasi_dan_berita_delete_error']		= 'You have not selected any records to delete.';
$lang['informasi_dan_berita_actions']			= 'Actions';
$lang['informasi_dan_berita_cancel']			= 'Cancel';
$lang['informasi_dan_berita_delete_record']		= 'Delete this Informasi dan Berita';
$lang['informasi_dan_berita_delete_confirm']	= 'Are you sure you want to delete this informasi_dan_berita?';
$lang['informasi_dan_berita_edit_heading']		= 'Edit Informasi dan Berita';

// Create/Edit Buttons
$lang['informasi_dan_berita_action_edit']		= 'Save Informasi dan Berita';
$lang['informasi_dan_berita_action_create']		= 'Create Informasi dan Berita';

// Activities
$lang['informasi_dan_berita_act_create_record']	= 'Created record with ID';
$lang['informasi_dan_berita_act_edit_record']	= 'Updated record with ID';
$lang['informasi_dan_berita_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['informasi_dan_berita_column_created']	= 'Created';
$lang['informasi_dan_berita_column_deleted']	= 'Deleted';
$lang['informasi_dan_berita_column_modified']	= 'Modified';
