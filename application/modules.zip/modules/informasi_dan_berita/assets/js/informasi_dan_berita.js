$('#informasi_dan_berita_tgl_create').datepicker({ dateFormat: 'yy-mm-dd'});
$('#informasi_dan_berita_jam').datetimepicker({ dateFormat: 'yy-mm-dd', timeFormat: 'hh:mm:ss'});
