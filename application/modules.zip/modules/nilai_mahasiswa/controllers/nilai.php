<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * nilai controller
 */
class nilai extends Admin_Controller
{

	//--------------------------------------------------------------------


	/**
	 * Constructor
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		$this->auth->restrict('Nilai_Mahasiswa.Nilai.View');
		$this->lang->load('nilai_mahasiswa');
		
		Template::set_block('sub_nav', 'nilai/_sub_nav');

		Assets::add_module_js('nilai_mahasiswa', 'nilai_mahasiswa.js');
		$this->load->model('datakrs/datakrs_model', null, true);
		
		//master matakuliah
		$this->load->model('mastermatakuliah/mastermatakuliah_model', null, true);
		$matakuliahs = $this->mastermatakuliah_model->find_all();
		Template::set('matakuliahs', $matakuliahs);
		
	}

	//--------------------------------------------------------------------


	/**
	 * Displays a list of form data.
	 *
	 * @return void
	 */
	public function index()
	{
		 
		// Deleting anything?
		if (isset($_POST['delete']))
		{
			$checked = $this->input->post('checked');

			if (is_array($checked) && count($checked))
			{
				$result = FALSE;
				foreach ($checked as $pid)
				{
					$result = $this->datakrs_model->delete($pid);
				}

				if ($result)
				{
					Template::set_message(count($checked) .' '. lang('datakrs_delete_success'), 'success');
				}
				else
				{
					Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
				}
			}
		}
		$kode_mk = $this->input->get('kode_mk');
		$mhs = $this->input->get('nama');
		$sms = $this->input->get('sms');
		
		$this->load->library('pagination');
		$total = $this->datakrs_model->count_all_fromdosen($sms,$kode_mk,$mhs,$this->current_user->nim);
		$offset = $this->input->get('per_page');
		$limit = $this->settings_lib->item('site.list_limit');

		$this->pager['base_url'] 			= current_url()."?sms=".$sms."&kode_mk=".$kode_mk."&mhs=".$mhs;
		$this->pager['total_rows'] 			= $total;
		$this->pager['per_page'] 			= $limit;
		$this->pager['page_query_string']	= TRUE;
		$this->pagination->initialize($this->pager);
		$records = $this->datakrs_model->limit($limit, $offset)->find_all_fromdosen($sms,$kode_mk,$mhs,$this->current_user->nim);

		Template::set('records', $records);
		Template::set('total', $total);
		
		Template::set('sms', $sms);
		
		Template::set('kode_mk', $kode_mk);
		Template::set('mhs', $mhs);
		
		Template::set('toolbar_title', 'Manage Nilai Mahasiswa');
		Template::render();
	}

	//--------------------------------------------------------------------


	/**
	 * Creates a Nilai Mahasiswa object.
	 *
	 * @return void
	 */
	public function create()
	{
		$this->auth->restrict('Nilai_Mahasiswa.Nilai.Create');

		Assets::add_module_js('nilai_mahasiswa', 'nilai_mahasiswa.js');

		Template::set('toolbar_title', lang('nilai_mahasiswa_create') . ' Nilai Mahasiswa');
		Template::render();
	}
	public function edit()
	{
		$id = $this->uri->segment(5);

		if (empty($id))
		{
			Template::set_message("Silahkan Pilih terlebih dahulu", 'error');
			redirect(SITE_AREA .'/nilai/nilai_mahasiswa');
		}

		if (isset($_POST['save']))
		{
			$this->auth->restrict('Nilai_Mahasiswa.Nilai.Create');

			if ($this->save_datakrs('update', $id))
			{
				// Log the activity
				log_activity($this->current_user->id, lang('datakrs_act_edit_record') .': '. $id .' : '. $this->input->ip_address(), 'datakrs');

				Template::set_message("Save Success", 'success');
			}
			else
			{
				Template::set_message("Save data Gagal" . $this->datakrs_model->error, 'error');
			}
		}
		 
		Template::set('datakrs', $this->datakrs_model->find($id));
		Template::set('toolbar_title', 'Edit Nilai');
		Template::render();
	}
	private function save_datakrs($type='insert', $id=0)
	{
		if ($type == 'update')
		{
			$_POST['id'] = $id;
		}

		// make sure we only pass in the fields we want
		
		$data = array();
		 
		$data['nilai_angka']        = $this->input->post('datakrs_nilai_angka');
		$data['nilai_huruf']        = $this->input->post('datakrs_nilai_huruf');
		 
		if ($type == 'insert')
		{
			$id = $this->datakrs_model->insert($data);

			if (is_numeric($id))
			{
				$return = $id;
			}
			else
			{
				$return = FALSE;
			}
		}
		elseif ($type == 'update')
		{
			$return = $this->datakrs_model->update($id, $data);
		}

		return $return;
	}

	//--------------------------------------------------------------------



}