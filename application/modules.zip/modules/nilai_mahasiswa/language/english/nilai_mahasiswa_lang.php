<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['nilai_mahasiswa_manage']			= 'Manage Nilai Mahasiswa';
$lang['nilai_mahasiswa_edit']				= 'Edit';
$lang['nilai_mahasiswa_true']				= 'True';
$lang['nilai_mahasiswa_false']				= 'False';
$lang['nilai_mahasiswa_create']			= 'Create';
$lang['nilai_mahasiswa_list']				= 'List';
$lang['nilai_mahasiswa_new']				= 'New';
$lang['nilai_mahasiswa_edit_text']			= 'Edit this to suit your needs';
$lang['nilai_mahasiswa_no_records']		= 'There aren\'t any nilai_mahasiswa in the system.';
$lang['nilai_mahasiswa_create_new']		= 'Create a new Nilai Mahasiswa.';
$lang['nilai_mahasiswa_create_success']	= 'Nilai Mahasiswa successfully created.';
$lang['nilai_mahasiswa_create_failure']	= 'There was a problem creating the nilai_mahasiswa: ';
$lang['nilai_mahasiswa_create_new_button']	= 'Create New Nilai Mahasiswa';
$lang['nilai_mahasiswa_invalid_id']		= 'Invalid Nilai Mahasiswa ID.';
$lang['nilai_mahasiswa_edit_success']		= 'Nilai Mahasiswa successfully saved.';
$lang['nilai_mahasiswa_edit_failure']		= 'There was a problem saving the nilai_mahasiswa: ';
$lang['nilai_mahasiswa_delete_success']	= 'record(s) successfully deleted.';
$lang['nilai_mahasiswa_delete_failure']	= 'We could not delete the record: ';
$lang['nilai_mahasiswa_delete_error']		= 'You have not selected any records to delete.';
$lang['nilai_mahasiswa_actions']			= 'Actions';
$lang['nilai_mahasiswa_cancel']			= 'Cancel';
$lang['nilai_mahasiswa_delete_record']		= 'Delete this Nilai Mahasiswa';
$lang['nilai_mahasiswa_delete_confirm']	= 'Are you sure you want to delete this nilai_mahasiswa?';
$lang['nilai_mahasiswa_edit_heading']		= 'Edit Nilai Mahasiswa';

// Create/Edit Buttons
$lang['nilai_mahasiswa_action_edit']		= 'Save Nilai Mahasiswa';
$lang['nilai_mahasiswa_action_create']		= 'Create Nilai Mahasiswa';

// Activities
$lang['nilai_mahasiswa_act_create_record']	= 'Created record with ID';
$lang['nilai_mahasiswa_act_edit_record']	= 'Updated record with ID';
$lang['nilai_mahasiswa_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['nilai_mahasiswa_column_created']	= 'Created';
$lang['nilai_mahasiswa_column_deleted']	= 'Deleted';
$lang['nilai_mahasiswa_column_modified']	= 'Modified';
