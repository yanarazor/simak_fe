<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * krs controller
 */
class krs extends Admin_Controller
{

	//--------------------------------------------------------------------


	/**
	 * Constructor
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->model('datakrs/datakrs_model', null, true);
		$this->lang->load('datakrs/datakrs');
		$this->auth->restrict('Krs_Mahasiswa.Krs.View');
		
		Assets::add_css('flick/jquery-ui-1.8.13.custom.css');
		Assets::add_js('jquery-ui-1.8.13.min.js');
		Template::set_block('sub_nav', 'krs/_sub_nav');
		
		Assets::add_module_js('datakrs', 'datakrs.js');
		
		//master matakuliah
		$this->load->model('mastermatakuliah/mastermatakuliah_model', null, true);
		$matakuliahs = $this->mastermatakuliah_model->find_all();
		Template::set('matakuliahs', $matakuliahs);
		$this->load->model('mastermahasiswa/mastermahasiswa_model', null, true);
		
		//master pilihan
		$this->load->model('pilihan/pilihan_model', null, true);
		$pilihansemester = $this->pilihan_model->find_all("sms");
		Template::set('pilihansemesters', $pilihansemester);
		
		//master Dosen
		$this->load->model('masterdosen/masterdosen_model', null, true);
		$dosens = $this->masterdosen_model->find_all();
		Template::set('dosens', $dosens);
		
		Assets::add_css('flick/jquery-ui-1.8.13.custom.css');
		Assets::add_js('jquery-ui-1.8.13.min.js');
		Assets::add_css('fancybox/jquery.fancybox-1.3.4.css');
		Assets::add_js('fancybox/jquery.fancybox-1.3.4.js');
		 
		 
	}

	//--------------------------------------------------------------------


	/**
	 * Displays a list of form data.
	 *
	 * @return void
	 */
	public function index()
	{
		// Deleting anything?
		if (isset($_POST['delete']))
		{
			$checked = $this->input->post('checked');

			if (is_array($checked) && count($checked))
			{
				$result = FALSE;
				foreach ($checked as $pid)
				{
					$result = $this->datakrs_model->delete($pid);
				}

				if ($result)
				{
					Template::set_message(count($checked) .' '. lang('datakrs_delete_success'), 'success');
				}
				else
				{
					Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
				}
			}
		}
		$sms = $this->input->get('sms');
		//$kode_mk = $this->input->get('kode_mk');
		$mhs = $this->input->get('mhs');
		 
		
		$this->load->library('pagination');
		$total = $this->datakrs_model->count_rekapadm($sms,$mhs);
		$offset = $this->input->get('per_page');
		$limit = $this->settings_lib->item('site.list_limit');

		$this->pager['base_url'] 			= current_url()."?sms=".$sms."&mhs=".$mhs;
		$this->pager['total_rows'] 			= $total;
		$this->pager['per_page'] 			= $limit;
		$this->pager['page_query_string']	= TRUE;
		$this->pagination->initialize($this->pager);
		$records = $this->datakrs_model->limit($limit, $offset)->rekapadm($sms,$mhs);
 
		Template::set('records', $records);
		if(isset($records) && is_array($records) && count($records))
			$total = $total;
		else
			$total = 0;
		Template::set('total', $total);
		
		Template::set('sms', $sms); 
		Template::set('mhs', $mhs);
		Template::set('toolbar_title', 'Manage KRS');
		Template::render(); 
	}

	//--------------------------------------------------------------------


	/**
	 * Creates a Krs Mahasiswa object.
	 *
	 * @return void
	 */
	public function create()
	{
		$this->auth->restrict('Krs_Mahasiswa.Krs.Create');
		if (isset($_POST['save']))
		{
			if ($insert_id = $this->save_datakrs())
			{
				// Log the activity
				log_activity($this->current_user->id, lang('datakrs_act_create_record') .': '. $insert_id .' : '. $this->input->ip_address(), 'datakrs');

				Template::set_message("Create data KRS Success", 'success');
				redirect(SITE_AREA .'/krs/krs_mahasiswa');
			}
			else
			{
				Template::set_message("Create Gagal". $this->datakrs_model->error, 'error');
			}
		}
		Assets::add_module_js('krs_mahasiswa', 'krs_mahasiswa.js');

		Template::set('toolbar_title', 'Create Krs Mahasiswa');
		Template::render();
	}

	//--------------------------------------------------------------------


	/**
	 * Allows editing of Krs Mahasiswa data.
	 *
	 * @return void
	 */
	public function edit()
	{
		$id = $this->uri->segment(5);

		if (empty($id))
		{
			Template::set_message(lang('datakrs_invalid_id'), 'error');
			redirect(SITE_AREA .'/krs/datakrs');
		}

		if (isset($_POST['save']))
		{
			$this->auth->restrict('DataKrs.Krs.Edit');

			if ($this->save_datakrs('update', $id))
			{
				// Log the activity
				log_activity($this->current_user->id, lang('datakrs_act_edit_record') .': '. $id .' : '. $this->input->ip_address(), 'datakrs');

				Template::set_message("Edit Success", 'success');
			}
			else
			{
				Template::set_message("Save error" . $this->datakrs_model->error, 'error');
			}
		}
		else if (isset($_POST['delete']))
		{
			$this->auth->restrict('DataKrs.Krs.Delete');

			if ($this->datakrs_model->delete($id))
			{
				// Log the activity
				log_activity($this->current_user->id, 'Delete data KRS id : '. $id .' : '. $this->input->ip_address(), 'datakrs');

				Template::set_message("Delete success", 'success');

				redirect(SITE_AREA .'/krs/krs_mahasiswa');
			}
			else
			{
				Template::set_message("Delete gagal" . $this->datakrs_model->error, 'error');
			}
		}
		Template::set('datakrs', $this->datakrs_model->find($id));

		Template::set('toolbar_title', 'Edit Krs Mahasiswa');
		Template::render();
	}
	public function detil()
	{
		$sms = $this->uri->segment(5);
		$mhs = $this->uri->segment(6);
		// Deleting anything?
		if (isset($_POST['delete']))
		{
			$checked = $this->input->post('checked');

			if (is_array($checked) && count($checked))
			{
				$result = FALSE;
				foreach ($checked as $pid)
				{
					$result = $this->datakrs_model->delete($pid);
				}

				if ($result)
				{
					Template::set_message(count($checked) .' '. lang('datakrs_delete_success'), 'success');
				}
				else
				{
					Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
				}
			}
		}
		$kode_mk = $this->input->get('kode_mk'); 
		$this->load->library('pagination');
		$total = $this->datakrs_model->count_all($sms,$kode_mk,$mhs);
		$offset = $this->input->get('per_page');
		$limit = $this->settings_lib->item('site.list_limit');

		$this->pager['base_url'] 			= current_url()."?sms=".$sms."&kode_mk=".$kode_mk."&mhs=".$mhs;
		$this->pager['total_rows'] 			= $total;
		$this->pager['per_page'] 			= $limit;
		$this->pager['page_query_string']	= TRUE;
		$this->pagination->initialize($this->pager);
		$records = $this->datakrs_model->limit($limit, $offset)->find_all($sms,$kode_mk,$mhs);

		Template::set('records', $records);
		Template::set('total', $total);
		
		Template::set('sms', $sms);
		//die($kode_mk);
		Template::set('kode_mk', $kode_mk);
		Template::set('mhs', $mhs);
		Template::set('toolbar_title', 'Manage KRS');
		Template::render();
	}
	public function listdata()
	{

		// Deleting anything?
		if (isset($_POST['delete']))
		{
			$checked = $this->input->post('checked');

			if (is_array($checked) && count($checked))
			{
				$result = FALSE;
				foreach ($checked as $pid)
				{
					$result = $this->datakrs_model->delete($pid);
				}

				if ($result)
				{
					Template::set_message(count($checked) .' '. lang('datakrs_delete_success'), 'success');
				}
				else
				{
					Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
				}
			}
		}
		$sms = $this->input->get('sms');
		$kode_mk = $this->input->get('kode_mk');
		$mhs = $this->input->get('mhs');
		 
		
		$this->load->library('pagination');
		$total = $this->datakrs_model->count_all($sms,$kode_mk,$mhs);
		$offset = $this->input->get('per_page');
		$limit = $this->settings_lib->item('site.list_limit');

		$this->pager['base_url'] 			= current_url()."?sms=".$sms."&kode_mk=".$kode_mk."&mhs=".$mhs;
		$this->pager['total_rows'] 			= $total;
		$this->pager['per_page'] 			= $limit;
		$this->pager['page_query_string']	= TRUE;
		$this->pagination->initialize($this->pager);
		$records = $this->datakrs_model->limit($limit, $offset)->find_all($sms,$kode_mk,$mhs);

		Template::set('records', $records);
		Template::set('total', $total);
		
		Template::set('sms', $sms);
		
		Template::set('kode_mk', $kode_mk);
		Template::set('mhs', $mhs);
		Template::set('toolbar_title', 'Manage KRS');
		Template::render();
	}
	public function printkrs()
	{
		$sms = $this->uri->segment(5);
		$mhs = $this->uri->segment(6); 
		$mode = $this->uri->segment(7); 
		//die($mode);
		if (empty($sms))
		{
			Template::set_message("Semua Semester.", 'warning');
			 
		}
		Template::set('sms', $sms);
		Template::set('mhs', $mhs);
		//Template::set('sms', $sms);
		$datakrs = $this->datakrs_model->find_all($sms,"",$mhs);
		Template::set('datakrs', $datakrs);
		
		//detil mahasiswa
		$datamahasiswa = $this->mastermahasiswa_model->find_detil($mhs);
		Template::set('datamahasiswa', $datamahasiswa);
		//print_r($datamahasiswa);
		Template::set_view('krs/printkrs');
		
		if($mode=="print"){
			//Assets::add_css('style.css');  
			Template::set_theme('print');
		}
		Template::set('toolbar_title', 'Print KRS');
		Template::render();
	}
	//--------------------------------------------------------------------

	private function save_datakrs($type='insert', $id=0)
	{
		if ($type == 'update')
		{
			$_POST['id'] = $id;
		}
		$this->form_validation->set_rules('datakrs_kode_mk','Mata kuliah','required|max_length[20]');
		$this->form_validation->set_rules('datakrs_sks','sks','required|max_length[5]');
		$this->form_validation->set_rules('datakrs_mahasiswa','Nim Mahasiswa','required|max_length[30]');
		$this->form_validation->set_rules('datakrs_kode_dosen','Dosen','required|max_length[20]');
		$this->form_validation->set_rules('datakrs_semester','Semester','required|max_length[3]');
		if ($this->form_validation->run() === FALSE)
		{
			return FALSE;
		}

		// make sure we only pass in the fields we want
		
		$data = array();
		$data['kode_mk']        = $this->input->post('datakrs_kode_mk');
		$data['sks']        = $this->input->post('datakrs_sks');
		$data['mahasiswa']        = $this->input->post('datakrs_mahasiswa');
		$data['kode_dosen']        = $this->input->post('datakrs_kode_dosen');
		$data['semester']        = $this->input->post('datakrs_semester');
		$data['kode_jadwal']        = $this->input->post('datakrs_kode_jadwal');
		$data['nilai_angka']        = $this->input->post('datakrs_nilai_angka');
		$data['nilai_huruf']        = $this->input->post('datakrs_nilai_huruf');
		$data['created_date']        = date("Y-m-d");// $this->input->post('datakrs_created_date') ? $this->input->post('datakrs_created_date') : '0000-00-00';

		if ($type == 'insert')
		{
			$id = $this->datakrs_model->insert($data);

			if (is_numeric($id))
			{
				$return = $id;
			}
			else
			{
				$return = FALSE;
			}
		}
		elseif ($type == 'update')
		{
			$return = $this->datakrs_model->update($id, $data);
		}

		return $return;
	}

}