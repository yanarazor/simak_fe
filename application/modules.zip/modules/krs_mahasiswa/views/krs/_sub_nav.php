<ul class="nav nav-pills">
	<li <?php echo $this->uri->segment(4) == '' ? 'class="active"' : '' ?>>
		<a href="<?php echo site_url(SITE_AREA .'/krs/krs_mahasiswa') ?>" id="list"><?php echo lang('datakrs_list'); ?></a>
	</li>
	<?php if ($this->auth->has_permission('Krs_Mahasiswa.Krs.Create')) : ?>
	<li <?php echo $this->uri->segment(4) == 'create' ? 'class="active"' : '' ?> >
		<a href="<?php echo site_url(SITE_AREA .'/krs/krs_mahasiswa/create') ?>" id="create_new"><?php echo lang('datakrs_new'); ?></a>
	</li>
	<?php endif; ?>
	 <?php if ($this->auth->has_permission('Krs_Mahasiswa.Krs.Create') and isset($sms)) : ?>
	<li <?php echo $this->uri->segment(4) == 'printjob' ? 'class="active"' : '' ?> >
		<a href="<?php echo site_url(SITE_AREA .'/krs/krs_mahasiswa/printkrs/'); echo isset($sms)? "/".$sms:""; echo isset($mhs)? "/".$mhs:""; ?>">Print Preview</a>
	</li>
	 <?php endif; ?>
	 
</ul>