<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['krs_mahasiswa_manage']			= 'Manage Krs Mahasiswa';
$lang['krs_mahasiswa_edit']				= 'Edit';
$lang['krs_mahasiswa_true']				= 'True';
$lang['krs_mahasiswa_false']				= 'False';
$lang['krs_mahasiswa_create']			= 'Create';
$lang['krs_mahasiswa_list']				= 'List';
$lang['krs_mahasiswa_new']				= 'New';
$lang['krs_mahasiswa_edit_text']			= 'Edit this to suit your needs';
$lang['krs_mahasiswa_no_records']		= 'There aren\'t any krs_mahasiswa in the system.';
$lang['krs_mahasiswa_create_new']		= 'Create a new Krs Mahasiswa.';
$lang['krs_mahasiswa_create_success']	= 'Krs Mahasiswa successfully created.';
$lang['krs_mahasiswa_create_failure']	= 'There was a problem creating the krs_mahasiswa: ';
$lang['krs_mahasiswa_create_new_button']	= 'Create New Krs Mahasiswa';
$lang['krs_mahasiswa_invalid_id']		= 'Invalid Krs Mahasiswa ID.';
$lang['krs_mahasiswa_edit_success']		= 'Krs Mahasiswa successfully saved.';
$lang['krs_mahasiswa_edit_failure']		= 'There was a problem saving the krs_mahasiswa: ';
$lang['krs_mahasiswa_delete_success']	= 'record(s) successfully deleted.';
$lang['krs_mahasiswa_delete_failure']	= 'We could not delete the record: ';
$lang['krs_mahasiswa_delete_error']		= 'You have not selected any records to delete.';
$lang['krs_mahasiswa_actions']			= 'Actions';
$lang['krs_mahasiswa_cancel']			= 'Cancel';
$lang['krs_mahasiswa_delete_record']		= 'Delete this Krs Mahasiswa';
$lang['krs_mahasiswa_delete_confirm']	= 'Are you sure you want to delete this krs_mahasiswa?';
$lang['krs_mahasiswa_edit_heading']		= 'Edit Krs Mahasiswa';

// Create/Edit Buttons
$lang['krs_mahasiswa_action_edit']		= 'Save Krs Mahasiswa';
$lang['krs_mahasiswa_action_create']		= 'Create Krs Mahasiswa';

// Activities
$lang['krs_mahasiswa_act_create_record']	= 'Created record with ID';
$lang['krs_mahasiswa_act_edit_record']	= 'Updated record with ID';
$lang['krs_mahasiswa_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['krs_mahasiswa_column_created']	= 'Created';
$lang['krs_mahasiswa_column_deleted']	= 'Deleted';
$lang['krs_mahasiswa_column_modified']	= 'Modified';
