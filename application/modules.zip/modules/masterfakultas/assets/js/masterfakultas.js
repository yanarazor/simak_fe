$('#masterfakultas_tgl_pendirian').datepicker({ dateFormat: 'yy-mm-dd'});
