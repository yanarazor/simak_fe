<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['masterfakultas_manage']			= 'Manage MasterFakultas';
$lang['masterfakultas_edit']				= 'Edit';
$lang['masterfakultas_true']				= 'True';
$lang['masterfakultas_false']				= 'False';
$lang['masterfakultas_create']			= 'Create';
$lang['masterfakultas_list']				= 'List';
$lang['masterfakultas_new']				= 'New';
$lang['masterfakultas_edit_text']			= 'Edit this to suit your needs';
$lang['masterfakultas_no_records']		= 'There aren\'t any masterfakultas in the system.';
$lang['masterfakultas_create_new']		= 'Create a new MasterFakultas.';
$lang['masterfakultas_create_success']	= 'MasterFakultas successfully created.';
$lang['masterfakultas_create_failure']	= 'There was a problem creating the masterfakultas: ';
$lang['masterfakultas_create_new_button']	= 'Create New MasterFakultas';
$lang['masterfakultas_invalid_id']		= 'Invalid MasterFakultas ID.';
$lang['masterfakultas_edit_success']		= 'MasterFakultas successfully saved.';
$lang['masterfakultas_edit_failure']		= 'There was a problem saving the masterfakultas: ';
$lang['masterfakultas_delete_success']	= 'record(s) successfully deleted.';
$lang['masterfakultas_delete_failure']	= 'We could not delete the record: ';
$lang['masterfakultas_delete_error']		= 'You have not selected any records to delete.';
$lang['masterfakultas_actions']			= 'Actions';
$lang['masterfakultas_cancel']			= 'Cancel';
$lang['masterfakultas_delete_record']		= 'Delete this MasterFakultas';
$lang['masterfakultas_delete_confirm']	= 'Are you sure you want to delete this masterfakultas?';
$lang['masterfakultas_edit_heading']		= 'Edit MasterFakultas';

// Create/Edit Buttons
$lang['masterfakultas_action_edit']		= 'Save MasterFakultas';
$lang['masterfakultas_action_create']		= 'Create MasterFakultas';

// Activities
$lang['masterfakultas_act_create_record']	= 'Created record with ID';
$lang['masterfakultas_act_edit_record']	= 'Updated record with ID';
$lang['masterfakultas_act_delete_record']	= 'Deleted record with ID';

// Column Headings
$lang['masterfakultas_column_created']	= 'Created';
$lang['masterfakultas_column_deleted']	= 'Deleted';
$lang['masterfakultas_column_modified']	= 'Modified';
