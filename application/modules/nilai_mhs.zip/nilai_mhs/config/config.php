<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Input Nilai Mahasiswa',
	'name'		=> 'Nilai Mahasiswa',
	'version'		=> '0.0.1',
	'author'		=> 'developer'
);