<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * nilai controller
 */
class nilai extends Admin_Controller
{

	//--------------------------------------------------------------------


	/**
	 * Constructor
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		$this->auth->restrict('Nilai_Mhs.Nilai.View');
		$this->lang->load('nilai_mhs');
		
		Template::set_block('sub_nav', 'nilai/_sub_nav');

		Assets::add_module_js('nilai_mhs', 'nilai_mhs.js');
		$this->load->model('datakrs/datakrs_model', null, true);
		
		//master matakuliah
		$this->load->model('mastermatakuliah/mastermatakuliah_model', null, true);
		$matakuliahs = $this->mastermatakuliah_model->find_distinct();
		Template::set('matakuliahs', $matakuliahs);
		
		//master Dosen
		$this->load->model('masterdosen/masterdosen_model', null, true);
		$dosens = $this->masterdosen_model->find_all();
		Template::set('dosens', $dosens);
		
		$this->load->model('pilihan/pilihan_model', null, true);
		$pilihansemester = $this->pilihan_model->find_all("sms");
		Template::set('pilihansemesters', $pilihansemester);
		
		$this->load->model('masterkelas/masterkelas_model', null, true);
		$pilihkelas = $this->masterkelas_model->find_distinct();
		Template::set('pilihkelas', $pilihkelas);
		
	}

	//--------------------------------------------------------------------


	/**
	 * Displays a list of form data.
	 *
	 * @return void
	 */
	public function index()
	{

		if (isset($_POST['delete']))
		{
			$checked = $this->input->post('checked');

			if (is_array($checked) && count($checked))
			{
				$result = FALSE;
				foreach ($checked as $pid)
				{
					$result = $this->datakrs_model->delete($pid);
				}

				if ($result)
				{
					Template::set_message(count($checked) .' '. lang('datakrs_delete_success'), 'success');
				}
				else
				{
					Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
				}
			}
		}
		//die("masuk");
		$kode_mk = $this->input->get('kode_mk');
		$kelas = $this->input->get('kelas');
		
		$this->load->library('pagination');
		$total = $this->datakrs_model->count_distinct_mk_kelas($kelas,$kode_mk);
		$offset = $this->input->get('per_page');
		$limit = $this->settings_lib->item('site.list_limit');

		$this->pager['base_url'] 			= current_url()."?kelas=".$kelas."&kode_mk=".$kode_mk;
		$this->pager['total_rows'] 			= $total;
		$this->pager['per_page'] 			= $limit;
		$this->pager['page_query_string']	= TRUE;
		$this->pagination->initialize($this->pager);
		$records = $this->datakrs_model->limit($limit, $offset)->distinct_mk_kelas($kelas,$kode_mk);
		
		Template::set('records', $records);
		Template::set('total', $total); 
		//Template::set('sms', $sms); 
		Template::set('kode_mk', $kode_mk);
		//Template::set('mhs', $mhs);
		
		Template::set('toolbar_title', '&nbsp;&nbsp; Pengelolaan Data Nilai Mahasiswa');
		Template::render();
	}
	public function view()
	{

		if (isset($_POST['delete']))
		{
			$checked = $this->input->post('checked');

			if (is_array($checked) && count($checked))
			{
				$result = FALSE;
				foreach ($checked as $pid)
				{
					$result = $this->datakrs_model->delete($pid);
				}

				if ($result)
				{
					Template::set_message(count($checked) .' '. lang('datakrs_delete_success'), 'success');
				}
				else
				{
					Template::set_message(lang('datakrs_delete_failure') . $this->datakrs_model->error, 'error');
				}
			}
		}
		//$id = $this->uri->segment(5);
		
		$kode_mk = $this->input->get('kode_mk');
		$mhs = $this->input->get('nama');
		$sms = $this->input->get('sms');
		$kelas = $this->input->get('kelas');
		
		$this->load->library('pagination');
		$total = $this->datakrs_model->count_nilai($sms,$kode_mk,$mhs);
		$offset = $this->input->get('per_page');
		$limit = $this->settings_lib->item('site.list_limit');

		$this->pager['base_url'] 			= current_url()."?sms=".$sms."&kode_mk=".$kode_mk."&mhs=".$mhs;
		$this->pager['total_rows'] 			= $total;
		$this->pager['per_page'] 			= $limit;
		$this->pager['page_query_string']	= TRUE;
		$this->pagination->initialize($this->pager);
		$records = $this->datakrs_model->limit($limit, $offset)->find_nilai($sms,$kode_mk,$mhs);

		Template::set('records', $records);
		Template::set('total', $total);
		
		Template::set('sms', $sms);
		
		Template::set('kode_mk', $kode_mk);
		Template::set('mhs', $mhs);
		
		Template::set('toolbar_title', '&nbsp;&nbsp; Pengelolaan Data Nilai Mahasiswa');
		Template::render();
	}

	//--------------------------------------------------------------------


	/**
	 * Creates a Nilai Mhs object.
	 *
	 * @return void
	 */
	public function create()
	{
		$this->auth->restrict('Nilai_Mhs.Nilai.Create');

		Assets::add_module_js('nilai_mhs', 'nilai_mhs.js');
		if (isset($_POST['save']))
		{
			if ($insert_id = $this->save_datakrs())
			{
				// Log the activity
				log_activity($this->current_user->id, lang('jadwal_act_create_record') .': '. $insert_id .' : '. $this->input->ip_address(), 'datakrs');

				Template::set_message("Save Nilai Sukses", 'success');
				redirect(SITE_AREA .'/nilai/nilai_mhs');
			}
			else
			{
				Template::set_message(lang('jadwal_create_failure') . $this->jadwal_model->error, 'error');
			}
		}
		 
			Template::set('toolbar_title', '&nbsp;&nbsp; Tambah Data Nilai Mahasiswa');
		Template::render();
	}

	//--------------------------------------------------------------------


	/**
	 * Allows editing of Nilai Mhs data.
	 *
	 * @return void
	 */
	public function edit()
	{
		$id = $this->uri->segment(5);
		$this->auth->restrict('Nilai_Mhs.Nilai.Edit');
		if (empty($id))
		{
			Template::set_message("Silahkan Pilih terlebih dahulu", 'error');
			redirect(SITE_AREA .'/nilai/nilai_mhs');
		}

		if (isset($_POST['save']))
		{
			

			if ($this->save_datakrs('update', $id))
			{
				// Log the activity
				log_activity($this->current_user->id, 'Update Nilai Sukses : '. $id .' : '. $this->input->ip_address(), 'datakrs');

				Template::set_message("Save Success", 'success');
			}
			else
			{
				Template::set_message("Save data Gagal" . $this->datakrs_model->error, 'error');
			}
		}
		 
		Template::set('datakrs', $this->datakrs_model->find($id));
		Template::set('toolbar_title', '&nbsp;&nbsp; Ubah Data Nilai Mahasiswa');
		Template::render();
	}

	//--------------------------------------------------------------------
	private function save_datakrs($type='insert', $id=0)
	{
		if ($type == 'update')
		{
			$_POST['id'] = $id;
		}

		// make sure we only pass in the fields we want
		
		$data = array();
		$data['kode_mk']        = $this->input->post('datakrs_kode_mk');
		$data['sks']        = $this->input->post('datakrs_sks');
		$data['mahasiswa']        = $this->input->post('datakrs_mahasiswa');
		$data['kode_dosen']        = $this->input->post('kode_dosen');
		$data['semester']        = $this->input->post('datakrs_semester');
		//$data['kode_jadwal']        = $this->input->post('datakrs_kode_jadwal');
		$data['nilai_angka']        = $this->input->post('datakrs_nilai_angka');
		$data['nilai_huruf']        = $this->input->post('datakrs_nilai_huruf');
		$data['created_date']        = date("Y-m-d");// $this->input->post('datakrs_created_date') ? $this->input->post('datakrs_created_date') : '0000-00-00';

		if ($type == 'insert')
		{
			$id = $this->datakrs_model->insert($data);

			if (is_numeric($id))
			{
				$return = $id;
			}
			else
			{
				$return = FALSE;
			}
		}
		elseif ($type == 'update')
		{
			$return = $this->datakrs_model->update($id, $data);
		}

		return $return;
	}


}