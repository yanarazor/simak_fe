$('#masterdosen_tgl_lahir_dosen').datepicker({ dateFormat: 'yy-mm-dd'});
